/* Name: uart.c
 * Project: AVR USB driver for CDC interface on Low-Speed USB
 * Author: Osamu Tamura
 * Creation Date: 2006-06-18
 * Tabsize: 4
 * Copyright: (c) 2006 by Recursion Co., Ltd.
 * License: Proprietary, free under certain conditions. See Documentation.
 *
 * 2006-07-08   adapted to higher baud rate by T.Kitazawa
 */
/*
General Description:
    This module implements the UART rx/tx system of the USB-CDC driver.

Note: This module violates the rule that interrupts must not be disabled for
longer than a couple of instructions (see usbdrv.h). Running UART interrupt
handlers with sei as the first instruction is not possible because it would
recurse immediately (the cause of the interrupt has not been removed). If
we collect the data and then call sei(), we win little. We therefore decide
to violate the rule. The effect on USB operation is, that packages may be
lost. This is equivalent to a package being dropped due to a CRC error. The
host will therefore retry the transfer after a timeout. It is therefore very
likely that no effect is seen at the application layer.
*/

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>   /* needed by usbdrv.h */
#include "../usbdrv-20090415/oddebug.h"
#include "../usbdrv-20090415/usbdrv.h"
#include "uart.h"
#include "buffer.h"

//#include "midi.h"

uchar genUsbCodeIndexByte(uchar statusByte, uchar cableIndex);
uchar getMidiMsgLengthByHeader(uchar statusByte);

int licznik = 0; //DEBUG
extern uchar sendEmptyFrame;
cBuffer MidiInBuff;
cBuffer* midiInBuff = &MidiInBuff;
typedef struct _midiMsg{
	uchar header;
	uchar msg[3];
	uchar len;
}midiMsg_t;

midiMsg_t midiMsg = {0,{0,0,0},0};
midiMsg_t midiMsgToSend = {0,{0,0,0},0};
uchar realtimeMsg[4] = {0,0,0,0};

/* UART buffer */
uchar    rx_buf[RX_SIZE], tx_buf[TX_SIZE];
uchar    urptr, uwptr, irptr, iwptr;

uchar	lastMessagePtr = 0;

#ifndef URSEL
#   define URSEL_MASK   0
#else
#   define URSEL_MASK   (1 << URSEL)
#endif

void uartInit(ulong baudrate, uchar parity, uchar stopbits, uchar databits)
{

	//EDIT  jesli w��czono MIDI to inicjujemy port zgodnie z MIDI :)
//	if(bit_is_clear(MIDI_SWITCH_PIN, MIDI_SWITCH_PIN_NR)) {
//		MIDI_UART_Init( MIDI_BAUDRATE );
//		LED_PORT&=~_BV(LED1); // bit wyzerowany 
//	} else {
	
		usbDWord_t   br;

    	br.dword = F_CPU / (8L * baudrate) - 1;
		UCSR0A  |= (1<<U2X0);

#if DEBUG_LEVEL < 1
    	/*    USART configuration    */
    	UCSR0B  = 0;
    	UCSR0C  = URSEL_MASK | ((parity==1? 3:parity)<<UPM00) | ((stopbits>>1)<<USBS0) | ((databits-5)<<UCSZ00);
    	UBRR0L  = br.bytes[0];
    	UBRR0H  = br.bytes[1];
#else
    	DBG1(0xf0, br.bytes, 2);
#endif /* DEBUG_LEVEL */

#if UART_RXINT
    	UCSR0B  = (1<<RXEN0) | (1<<TXEN0) | (1<<RXCIE0);
#else
    	UCSR0B  = (1<<RXEN0) | (1<<TXEN0);
#endif
//	}
		//EDIT  jesli w��czono MIDI to inicjujemy port zgodnie z MIDI :)
//	if(bit_is_clear(MIDI_SWITCH_PIN, MIDI_SWITCH_PIN_NR)) {
		/* Set the baud rate */
		int midi_baudrate = MIDI_BAUDRATE;
		MIDI_UBRRH = (unsigned char) (midi_baudrate>>8);                  
		MIDI_UBRRL = (unsigned char) midi_baudrate;
//		LED_PORT&=~_BV(LED1); // bit wyzerowany 

		// EDIT dodaje "Reset!\n\r"
/*		uchar   iwnxt;
		uchar	resetString[] = {'R','e','s','e','t','!','\n','\r'};
		uchar	i;
        iwnxt = (iwptr+8) & RX_MASK;
        
		if (iwnxt!=urptr ) {
        	for(i=0; i<8; i++){ 					//8 - d�ugo�� resetStringa
				rx_buf[iwptr++] = resetString[i];
            	//iwptr = iwnxt;
			}
        }
*/
//	}
		bufferInit(midiInBuff, rx_buf, RX_SIZE);

}

void uartPoll(void)
{

	/*  host => device  */
	if( (UCSR0A&(1<<UDRE0)) && uwptr!=irptr ) {
        UDR0    = tx_buf[irptr];
        irptr   = (irptr + 1) & TX_MASK;

        if( usbAllRequestsAreDisabled() && uartTxBytesFree()>8 ) {
            usbEnableAllRequests();
        }
    }

	/*  host <= device  */
    if( usbInterruptIsReady() && (/*iwptr!=urptr ||*/midiInBuff->datalength /*|| sendEmptyFrame*/) ) {

		uchar data = bufferGetFromFront(midiInBuff);
		uchar intAlreadySet = 0;
		if(data >= 0x80) {  // if status byte recived (> 127)
			realtimeMsg[0] = genUsbCodeIndexByte(data,0);	// in case of realtime message
			if ( 1 == getMidiMsgLengthByHeader(realtimeMsg[0])){
				realtimeMsg[1] = data;
				usbSetInterrupt((uchar*)&realtimeMsg,4);
				intAlreadySet = 1;
			} else {
				//send Msg
				midiMsgToSend = midiMsg;
				usbSetInterrupt((uchar*)&midiMsgToSend, 4); //4 - the rest is, and must be zeros
				intAlreadySet = 1;
				sendEmptyFrame = 1;		// end transfer (neccessery ??)
			
				//cleanup
				midiMsg.len = 0;
				midiMsg.msg[0] = 0; midiMsg.msg[1] = 0; midiMsg.msg[2] = 0;
				midiMsg.header = 0;

				//prepare new msg
				midiMsg.header = genUsbCodeIndexByte(data,0);
				midiMsg.msg[0] = data;
				midiMsg.len = 1;
			}
		} else if (midiMsg.len > 0 && midiMsg.len < getMidiMsgLengthByHeader(midiMsg.header)) {
			midiMsg.msg[midiMsg.len++] = data;
		} else if (midiMsg.len == 0) {							//Trick with not sending status 
			midiMsg.header = midiMsgToSend.header;				//byte if last is the same
			midiMsg.msg[midiMsg.len++] = midiMsgToSend.msg[0];	//described : http://www.avrfreaks.net/modules/FreaksArticles/files/19/Midi%20and%20the%20AVR.pdf
			midiMsg.msg[midiMsg.len++] = data;
						//simply copy status byte from last Msg, and usb header of course
		} else {				// the same as above, but old Msg not send.
			//send Msg
			midiMsgToSend = midiMsg;
			usbSetInterrupt((uchar*)&midiMsgToSend, 4); //4 - the rest is, and must be zeros
			intAlreadySet = 1;
			sendEmptyFrame = 1;		// end transfer (neccessery ??)
			
			//cleanup
			midiMsg.len = 0;
			midiMsg.msg[0] = 0; midiMsg.msg[1] = 0; midiMsg.msg[2] = 0;
			midiMsg.header = 0;

			// copy statusbyte from old :)
			midiMsg.header = midiMsgToSend.header;
			midiMsg.msg[midiMsg.len++] = midiMsgToSend.msg[0];
			midiMsg.msg[midiMsg.len++] = data;
		}
			
		if (midiMsg.len >= getMidiMsgLengthByHeader(midiMsg.header) && !intAlreadySet) { // if msg complete
			//send Msg
			midiMsgToSend = midiMsg;
			usbSetInterrupt((uchar*)&midiMsgToSend, 4); //4 - the rest is, and must be zeros
			sendEmptyFrame = 1;		// end transfer (neccessery ??)
			
			//cleanup
			midiMsg.len = 0;
			midiMsg.msg[0] = 0; midiMsg.msg[1] = 0; midiMsg.msg[2] = 0;
			midiMsg.header = 0;
		}

		
/*        uchar   bytesRead;
		
        bytesRead = iwptr>=urptr? (iwptr-urptr):(RX_SIZE-urptr);        
		if(bytesRead >=4 ) {				//EDIT !!! nie bylo wcale mo�e by� b��d !!
			if(rx_buf[urptr+1] < 0x80) {	// EDIT!! drop bytes if  //not starting in 4 byte allign
				urptr = lastMessagePtr; 	// if not haveing midi status at 2nd. byte :P		
			}
			
			if(bytesRead>4)					// EDIT !!! bylo 8
            	bytesRead = 4;				//

			LED_PORT &= ~_BV(LED3);				//DEBUG
 //       	usbSetInterrupt(rx_buf+urptr, bytesRead);
        	urptr   += bytesRead;
        	urptr   &= RX_MASK;
*/
        	/* send an empty block after last data block to indicate transfer end */
//        	sendEmptyFrame = (bytesRead==4 && iwptr==urptr)? 1:0;
//		}
  //  } else {
		// DEBIUG !!
	//	
	}
/*	
	licznik++;
	if(licznik == 0){
		uchar tmpData[4] = { 0x09, 0x91, 0x50, 0x50 };
		
		usbSetInterrupt(tmpData, 4);
	} else if(licznik == 127) {
		uchar tmpData[4] = { 0x08, 0x81, 0x50, 0x50 };
		
		usbSetInterrupt(tmpData, 4);
	}
*/
//#if !UART_RXINT
	/*  recieve char from USART */
	if( UCSR0A&(1<<RXC0) ) {
        uchar   status, data;
//
        status  = UCSR0A;
        data    = UDR0;
        status  &= (1<<FE0) | (1<<DOR0) | (1<<UPE0);
        if(status == 0) { /* no receiver error occurred */
			
			bufferAddToEnd(midiInBuff, data);
/*			
            uchar   iwnxt;
			
			if(data >= 0x80) {  // if status byte recived (> 127)
				iwnxt = (iwptr+1) & RX_MASK;
				LED_PORT &= ~_BV(LED2);				//DEBUG
				//while (iwptr - lastMessagePtr % 4) {	//4 bytes frame size
				//	if( iwnxt!=urptr ) {		
                //		rx_buf[iwptr] = 0;		// ADD usb frame fill with zeros
                //		iwptr = iwnxt;
				//	}
				//	iwnxt = (iwptr+1) & RX_MASK;

				//}
				if( iwnxt!=urptr ) {		
                	rx_buf[iwptr] = genUsbCodeIndexByte(data, 0x0);		// ADD usb CONTROL data (NOTE EVENT)
					lastMessagePtr = iwptr;
                	iwptr = iwnxt;
				}
			}
            iwnxt = (iwptr+1) & RX_MASK;
            if( iwnxt!=urptr ) {
                rx_buf[iwptr] = data;
                iwptr = iwnxt;
            }
*/        
		} else {					// error occured during recive
			LED_PORT &= ~_BV(LED2);				//DEBUG
		}
    } else {						// no incoming data

	//LED_PORT|=_BV(LED2); // DEBUG
	//LED_PORT |= _BV(LED3);				//DEBUG
	}
//#endif
}


uchar genUsbCodeIndexByte(uchar statusByte, uchar cableIndex)
{
	uchar code = 0;

	code = cableIndex << 4;
	if (statusByte < 0xF0) {	//- "normal" midi msg
		code |= statusByte >> 4;
	} else {					//- SysEx and other "strangers" (?)
		switch (statusByte){
			case 0b11110000:	code |= 0x4; break;	//System Exclusive.\ This message makes up for all that MIDI doesn't support.
			case 0b11110001:	code |= 0x2; break;	//MTC
			case 0b11110010:	code |= 0x3; break;	//Song Position Pointer. 
			case 0b11110011:	code |= 0x2; break;	//Song Select. 
			case 0b11110110:	code |= 0x5; break;	//Tune Request.
			case 0b11110111:	code |= 0x5; break;	//End of Exclusive. \Used to terminate a System Exclusive dump //BAD!?
			case 0b11111001:	code |= 0x5; break;	//MIDI tick
			default: code |= 0x5;	// other are single byte System Common Messages
			
		}
	}

	return code;		//
}

uchar getMidiMsgLengthByHeader(uchar headerByte)
{
	uchar codeIndexNumber = headerByte & 0x0F; // mask channel number
	uchar len = 0;
	switch(codeIndexNumber){
		case 0x0:  len = 3; break; //Miscellaneous function codes. Reserved for future extensions. 1,2 or 3 bytes ;/
		case 0x1:  len = 3; break; //Cable events. Reserved for future expansion. 1,2 or 3 bytes ;/
		case 0x2:  len = 2; break;	//Two-byte System Common messages like MTC, SongSelect, etc.
		case 0x3:  len = 3; break;	//Three-byte System Common messages like SPP, etc.
		case 0x4:  len = 3; break;	//SysEx starts or continues
		case 0x5:  len = 1; break;	//Single-byte System Common Message \or \SysEx ends with following single byte.
		case 0x6:  len = 2; break;	//SysEx ends with following two bytes.
		case 0x7:  len = 3; break;	//SysEx ends with following three bytes.
		case 0x8:  len = 3; break;	//Note-off
		case 0x9:  len = 3; break;	//Note-on
		case 0xA:  len = 3; break;	//Poly-KeyPress
		case 0xB:  len = 3; break;	//Control Change
		case 0xC:  len = 2; break;	//Program Change
		case 0xD:  len = 2; break;	//Channel Pressure
		case 0xE:  len = 3; break;	//PitchBend Change
		case 0xF:  len = 1; break;	//Single Byte
		default: len = 3;
	}

	return len;
}


/*
uchar getMidiMsgLengthByHeader(uchar statusByte)
{
	uchar stat = statusByte & 0xF0; // mask channel number
	uchar len = 0;
	switch(stat){
		case 0x00:  len = 3; break; //Miscellaneous function codes. Reserved for future extensions. 1,2 or 3 bytes ;/
		case 0x10:  len = 3; break; //Cable events. Reserved for future expansion. 1,2 or 3 bytes ;/
		case 0x20:  len = 2; break;	//Two-byte System Common messages like MTC, SongSelect, etc.
		case 0x30:  len = 3; break;	//Three-byte System Common messages like SPP, etc.
		case 0x40:  len = 3; break;	//SysEx starts or continues
		case 0x50:  len = 1; break;	//Single-byte System Common Message \or \SysEx ends with following single byte.
		case 0x60:  len = 2; break;	//SysEx ends with following two bytes.
		case 0x70:  len = 3; break;	//SysEx ends with following three bytes.
		case 0x80:  len = 3; break;	//Note-off
		case 0x90:  len = 3; break;	//Note-on
		case 0xA0:  len = 3; break;	//Poly-KeyPress
		case 0xB0:  len = 3; break;	//Control Change
		case 0xC0:  len = 2; break;	//Program Change
		case 0xD0:  len = 2; break;	//Channel Pressure
		case 0xE0:  len = 3; break;	//PitchBend Change
		case 0xF0:  len = 1; break;	//Single Byte
		default: len = 3;
	}

	return len;
}
*/
//inline void sendAndClear(midiMsg_t* midi_msg, midiMsg_T)